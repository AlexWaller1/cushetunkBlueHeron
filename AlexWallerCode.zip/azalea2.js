console.log("Hello World");

let result = "(ab(c(defg)hi(jk)))";

let result2 = "ab(cd(efg(h)";

let result3 = "ab)cd)efg)h)";

let validParentheses = string => {
  let openSet = new Set();
  let closeSet = new Set();

  let count1 = 0; // (
  let count2 = 0; // )
  // if (count1 < count2) return false
  let count3 = 0; // [
  let count4 = 0; // ]
  // if (count3 < count4) return false
  let count5 = 0; // {
  let count6 = 0; // }
  // if (count5 < count6) return false
  // [(])

  let i = 0;

  for (; i < string.length; i++) {
    if (string.charAt(i) == "(") {
      count1++;
    }
    if (string.charAt(i) == ")") {
      count2++;
    }
    if (count1 < count2) {
      return false;
    }
  }

  if (count1 == 0 && count2 == 0) {
    return false;
  }

  if (count1 == count2) {
    return true;
  }

  if (count1 !== count2) {
    return false;
  }
};

console.log(validParentheses(result));
// true
console.log(validParentheses(result2));
// false
console.log(validParentheses(result3));
// false
console.log(validParentheses("a(b)c)((a)aaa"));
// false
console.log(validParentheses("test"));

// a)b)c(d(
// a(b)c)((a)aaa
// (a()
//

// )
// ( openCount++
// ) closeCount++
// if (openCount < closeCount) return false;

console.log(0 == 0);
console.log(0 === 0);

console.log("hello");

let validTwo = string => {
  let charsArray = [];

  let i = 0;
  for (; i < string.length; i++) {
    let char = string.charAt(i);
    if (char == "(" || char == ")") {
      charsArray.push(char);
    }
    if (char == "[" || char == "]") {
      charsArray.push(char);
    }
    if (char == "{" || char == "}") {
      charsArray.push(char);
    }
  }

  if (charsArray.length % 2 !== 0) {
    return false;
  }

  let openMap = new Map();
  openMap.set("(", 1);
  openMap.set("[", 2);
  openMap.set("{", 3);

  let closeMap = new Map();
  closeMap.set(")", 1);
  closeMap.set("]", 2);
  closeMap.set("}", 3);

  if (closeMap.has(charsArray[0])) {
    return false;
  }

  let key = "";
  let j = 0;
  let openNum = 0;
  let closeNum = 0;

  // [(])
  // if

  for (; j < charsArray.length; j++) {
    key = charsArray[i];
    if (openMap.has(key)) {
      openNum = openMap.get(key);
    }
    if (closeMap.has(key)) {
      closeNum = closeMap.get(key);
    }
    if (openNum !== closeNum) {
      return false;
    }
  }
  return true;
};

// console.log(validTwo("[a(s]k)"));

//---------------------------------------------------
//-------------------------------------------------

let string1 = "abcdeabcdefc";

let string2 = "abccdeaabbcddef";

let allStringCombos = string => {
  let rArray = [];

  let i = 0;
  for (; i < string.length; i++) {
    let subString = string.charAt(i);
    rArray.push(subString);
    let j = i + 1;
    for (; j < string.length; j++) {
      subString = subString.concat(string.charAt(j));
      rArray.push(subString);
    }
  }
  return rArray;
};

let noRepeatingChar = string => {
  let subStrings = allStringCombos(string);

  let i = 0;
  let noRepeat = [];
  for (; i < subStrings.length; i++) {
    let charMap = new Set();
    let j = 0;
    for (; j < subStrings[i]; j++) {
      if (charMap.has(subString[i].charAt(j))) {
      }
    }
  }

  let max = noRepeat[0];
};
